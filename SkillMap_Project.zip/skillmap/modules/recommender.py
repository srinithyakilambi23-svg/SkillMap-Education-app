"""
recommender.py
---------------
Rule-based (NOT ML) career matching engine.
Deliberately avoids scikit-learn for this part -- weighted set
overlap is transparent, fast, and easy to explain to judges.

Every function here works on plain Python lists/dicts, so it can be
unit-tested with fake data before any Streamlit UI exists.
"""

import pandas as pd
from utils.constants import CAREERS_CSV, TOP_N_CAREERS


def load_careers(path=CAREERS_CSV):
    """
    Loads careers.csv and parses the semicolon-separated skill/weight
    columns into Python lists. Returns a list of dicts, one per career.
    """
    df = pd.read_csv(path)
    careers = []
    for _, row in df.iterrows():
        skills = [s.strip().lower() for s in str(row["required_skills"]).split(";")]
        weights = [float(w) for w in str(row["skill_weights"]).split(";")]
        careers.append({
            "career_id": row["career_id"],
            "career_name": row["career_name"],
            "required_skills": skills,
            "skill_weights": dict(zip(skills, weights)),
            "min_cgpa": row["min_cgpa"],
            "description": row["description"],
        })
    return careers


def compute_match(student_skills, career):
    """
    Core matching algorithm.

    student_skills : list[str]  (already lowercased)
    career         : one dict from load_careers()

    Returns: match_percent (float, 0-100)

    Formula (weighted):
        match% = (sum of weights of matched skills)
                  / (sum of weights of all required skills) * 100
    """
    student_set = set(s.strip().lower() for s in student_skills)
    required_set = set(career["required_skills"])
    weights = career["skill_weights"]

    matched = student_set & required_set

    matched_weight = sum(weights[skill] for skill in matched)
    total_weight = sum(weights.values())

    if total_weight == 0:
        return 0.0

    return round((matched_weight / total_weight) * 100, 1)


def get_top_careers(student_skills, n=TOP_N_CAREERS, careers=None):
    """
    Returns the top-n careers for a student, sorted by match_percent
    descending. Each item is a dict:
        {career_name, match_percent, description, required_skills}
    """
    if careers is None:
        careers = load_careers()

    results = []
    for career in careers:
        match_percent = compute_match(student_skills, career)
        results.append({
            "career_id": career["career_id"],
            "career_name": career["career_name"],
            "match_percent": match_percent,
            "description": career["description"],
            "required_skills": career["required_skills"],
            "min_cgpa": career["min_cgpa"],
        })

    results.sort(key=lambda x: x["match_percent"], reverse=True)
    return results[:n]


# ---- Quick manual test (run: python -m modules.recommender) ----
if __name__ == "__main__":
    dummy_student_skills = ["python", "sql", "git"]
    top = get_top_careers(dummy_student_skills)
    for career in top:
        print(f"{career['career_name']}: {career['match_percent']}%")
