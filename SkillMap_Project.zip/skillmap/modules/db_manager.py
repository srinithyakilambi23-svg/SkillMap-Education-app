"""
db_manager.py
--------------
Single point of contact for SQLite. No other module should open
a raw sqlite3 connection -- everything goes through these functions.
This is what keeps Person 1 (UI) and Person 2 (backend/data) from
stepping on each other's code.
"""

import sqlite3
from datetime import datetime
from utils.constants import DB_PATH


def get_connection():
    """Returns a new SQLite connection with row access by column name."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def init_db():
    """
    Creates all tables if they don't already exist.
    Safe to call every time the app starts (CREATE TABLE IF NOT EXISTS).
    """
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS students (
            student_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            cgpa REAL,
            department TEXT,
            year INTEGER,
            target_career TEXT,
            interests TEXT,
            projects TEXT,
            created_at TIMESTAMP
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS student_skills (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            skill_name TEXT NOT NULL,
            FOREIGN KEY (student_id) REFERENCES students (student_id)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS student_certifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            cert_name TEXT NOT NULL,
            FOREIGN KEY (student_id) REFERENCES students (student_id)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS progress_tracker (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            skill_name TEXT NOT NULL,
            status TEXT DEFAULT 'not_started',
            updated_at TIMESTAMP,
            FOREIGN KEY (student_id) REFERENCES students (student_id)
        )
    """)

    conn.commit()
    conn.close()


def insert_student(name, cgpa, department, year, target_career,
                    skills, certifications, interests=None, projects=""):
    """
    Inserts a full student profile (student + skills + certifications)
    in one call. Returns the new student_id.

    skills: list[str]
    certifications: list[str]
    interests: list[str] or None
    """
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        INSERT INTO students (name, cgpa, department, year, target_career,
                               interests, projects, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        name, cgpa, department, year, target_career,
        ",".join(interests) if interests else "",
        projects,
        datetime.now().isoformat(),
    ))
    student_id = cur.lastrowid

    for skill in skills:
        cur.execute(
            "INSERT INTO student_skills (student_id, skill_name) VALUES (?, ?)",
            (student_id, skill.strip().lower()),
        )

    for cert in certifications:
        if cert.strip():
            cur.execute(
                "INSERT INTO student_certifications (student_id, cert_name) VALUES (?, ?)",
                (student_id, cert.strip()),
            )

    conn.commit()
    conn.close()
    return student_id


def get_student(student_id):
    """Returns a dict with the student's profile + skills + certifications."""
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("SELECT * FROM students WHERE student_id = ?", (student_id,))
    student_row = cur.fetchone()
    if student_row is None:
        conn.close()
        return None
    student = dict(student_row)

    cur.execute("SELECT skill_name FROM student_skills WHERE student_id = ?", (student_id,))
    student["skills"] = [row["skill_name"] for row in cur.fetchall()]

    cur.execute("SELECT cert_name FROM student_certifications WHERE student_id = ?", (student_id,))
    student["certifications"] = [row["cert_name"] for row in cur.fetchall()]

    conn.close()
    return student


def get_all_students():
    """Returns a list of (student_id, name) tuples -- useful for a picker/dropdown."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT student_id, name FROM students ORDER BY created_at DESC")
    rows = cur.fetchall()
    conn.close()
    return [(row["student_id"], row["name"]) for row in rows]


def save_progress(student_id, skill_name, status):
    """
    Inserts or updates the progress status for one skill.
    status must be one of: 'not_started', 'in_progress', 'completed'
    """
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        SELECT id FROM progress_tracker
        WHERE student_id = ? AND skill_name = ?
    """, (student_id, skill_name))
    existing = cur.fetchone()

    if existing:
        cur.execute("""
            UPDATE progress_tracker SET status = ?, updated_at = ?
            WHERE id = ?
        """, (status, datetime.now().isoformat(), existing["id"]))
    else:
        cur.execute("""
            INSERT INTO progress_tracker (student_id, skill_name, status, updated_at)
            VALUES (?, ?, ?, ?)
        """, (student_id, skill_name, status, datetime.now().isoformat()))

    conn.commit()
    conn.close()


def get_progress(student_id):
    """Returns a dict {skill_name: status} for the given student."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT skill_name, status FROM progress_tracker WHERE student_id = ?
    """, (student_id,))
    rows = cur.fetchall()
    conn.close()
    return {row["skill_name"]: row["status"] for row in rows}
