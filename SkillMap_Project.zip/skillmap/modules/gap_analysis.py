"""
gap_analysis.py
----------------
Computes which required skills a student is missing for a given career.
Deliberately tiny -- this is a pure set-difference operation once
recommender.py has done the heavy lifting.
"""


def get_missing_skills(student_skills, required_skills):
    """
    student_skills   : list[str]
    required_skills  : list[str]  (from a career's required_skills)

    Returns: list[str] of skills the student does NOT yet have,
             in the same order they appear in required_skills
             (keeps roadmap generation deterministic).
    """
    student_set = set(s.strip().lower() for s in student_skills)
    missing = [skill for skill in required_skills if skill not in student_set]
    return missing


def get_matched_skills(student_skills, required_skills):
    """Returns the skills the student already has that the career needs."""
    student_set = set(s.strip().lower() for s in student_skills)
    matched = [skill for skill in required_skills if skill in student_set]
    return matched


def gap_summary(student_skills, career):
    """
    Convenience wrapper: given a student's skills and one career dict
    (from recommender.load_careers()), returns a full breakdown.
    """
    required = career["required_skills"]
    missing = get_missing_skills(student_skills, required)
    matched = get_matched_skills(student_skills, required)

    return {
        "career_name": career["career_name"],
        "matched_skills": matched,
        "missing_skills": missing,
        "matched_count": len(matched),
        "missing_count": len(missing),
        "total_required": len(required),
    }


# ---- Quick manual test ----
if __name__ == "__main__":
    from modules.recommender import load_careers

    dummy_skills = ["python", "sql", "git"]
    careers = load_careers()
    ml_engineer = next(c for c in careers if c["career_name"] == "ML Engineer")

    summary = gap_summary(dummy_skills, ml_engineer)
    print(summary)
