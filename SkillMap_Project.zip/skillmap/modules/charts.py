"""
charts.py
----------
Every function here takes plain data and returns a Plotly figure
object. No Streamlit calls inside this file -- pages/2_Dashboard.py
is the only place that calls st.plotly_chart(fig).
Keeping this separation lets you unit-test charts by just calling
fig.show() locally without running the full app.
"""

import plotly.graph_objects as go
from utils.constants import THEME


def radar_chart(matched_skills, missing_skills, career_name):
    """
    Skill-coverage radar chart for one career.
    Every required skill for the career is a spoke; value = 1 if the
    student has it, 0 if it's a gap.
    """
    all_skills = matched_skills + missing_skills
    values = [1 for _ in matched_skills] + [0 for _ in missing_skills]

    # close the loop for a proper radar shape
    all_skills_closed = all_skills + [all_skills[0]] if all_skills else []
    values_closed = values + [values[0]] if values else []

    fig = go.Figure()
    fig.add_trace(go.Scatterpolar(
        r=values_closed,
        theta=all_skills_closed,
        fill='toself',
        name=career_name,
        line_color=THEME["primary"],
        fillcolor=THEME["primary"],
        opacity=0.6,
    ))
    fig.update_layout(
        polar=dict(
            radialaxis=dict(visible=True, range=[0, 1], showticklabels=False),
        ),
        showlegend=False,
        title=f"Skill Coverage — {career_name}",
        paper_bgcolor="rgba(0,0,0,0)",
        font_color=THEME["text"],
    )
    return fig


def career_match_bar_chart(top_careers):
    """
    Horizontal bar chart ranking the top recommended careers by
    match percentage. top_careers: output of recommender.get_top_careers()
    """
    names = [c["career_name"] for c in top_careers][::-1]
    scores = [c["match_percent"] for c in top_careers][::-1]

    fig = go.Figure(go.Bar(
        x=scores,
        y=names,
        orientation='h',
        marker_color=THEME["secondary"],
        text=[f"{s}%" for s in scores],
        textposition="outside",
    ))
    fig.update_layout(
        title="Top Career Matches",
        xaxis_title="Match %",
        xaxis_range=[0, 100],
        paper_bgcolor="rgba(0,0,0,0)",
        font_color=THEME["text"],
    )
    return fig


def gap_donut_chart(matched_count, missing_count):
    """Donut chart showing matched vs missing skill count for one career."""
    fig = go.Figure(go.Pie(
        labels=["Skills You Have", "Skills To Learn"],
        values=[matched_count, missing_count],
        hole=0.55,
        marker_colors=[THEME["secondary"], THEME["accent"]],
    ))
    fig.update_layout(
        title="Skill Gap Breakdown",
        paper_bgcolor="rgba(0,0,0,0)",
        font_color=THEME["text"],
    )
    return fig


def progress_gauge(completed, total):
    """Gauge chart showing % of gap skills marked 'completed'."""
    percent = round((completed / total) * 100, 1) if total > 0 else 0

    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=percent,
        title={"text": "Roadmap Progress"},
        gauge={
            "axis": {"range": [0, 100]},
            "bar": {"color": THEME["primary"]},
        },
    ))
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        font_color=THEME["text"],
    )
    return fig
