"""
roadmap_generator.py
----------------------
Turns a list of missing skills into an ordered, resource-backed
learning roadmap.

Step 1: look up each missing skill in resources.csv
Step 2: sort that skill's resources by difficulty/step_order
Step 3: sequence the SKILLS themselves using a small hardcoded
        prerequisite map, so "python" is always recommended before
        "pandas", etc.
"""

import pandas as pd
from utils.constants import RESOURCES_CSV

# A minimal prerequisite map for the most common skill chains.
# Skills not listed here just keep their original order.
PREREQUISITES = {
    "pandas": ["python"],
    "numpy": ["python"],
    "scikit-learn": ["python", "pandas", "numpy"],
    "machine learning": ["python", "statistics"],
    "deep learning": ["python", "machine learning"],
    "tensorflow": ["python", "machine learning"],
    "pytorch": ["python", "machine learning"],
    "nlp": ["python", "machine learning"],
    "computer vision": ["python", "deep learning"],
    "django": ["python"],
    "flask": ["python"],
    "react": ["javascript", "html", "css"],
    "node.js": ["javascript"],
    "kubernetes": ["docker"],
    "power bi": ["excel"],
}


def load_resources(path=RESOURCES_CSV):
    """Loads resources.csv into a dict: {skill_name: [resource_dict, ...]}"""
    df = pd.read_csv(path)
    resources = {}
    for _, row in df.iterrows():
        skill = row["skill_name"].strip().lower()
        resources.setdefault(skill, []).append({
            "title": row["resource_title"],
            "url": row["resource_url"],
            "difficulty": row["difficulty"],
            "step_order": row["step_order"],
        })

    # sort each skill's resource list by step_order (beginner -> advanced)
    for skill in resources:
        resources[skill].sort(key=lambda r: r["step_order"])

    return resources


def _sequence_skills(missing_skills):
    """
    Orders missing_skills so prerequisites come first, using a simple
    topological pass over the PREREQUISITES map. Anything without a
    known prerequisite keeps its original relative order.
    """
    ordered = []
    remaining = list(missing_skills)

    # Repeatedly pull out skills whose prerequisites are already
    # satisfied (either not in the gap list, or already ordered).
    max_passes = len(remaining) + 1
    passes = 0
    while remaining and passes < max_passes:
        passes += 1
        for skill in list(remaining):
            prereqs = PREREQUISITES.get(skill, [])
            unmet = [p for p in prereqs if p in remaining]
            if not unmet:
                ordered.append(skill)
                remaining.remove(skill)

    ordered.extend(remaining)  # safety net for any leftovers
    return ordered


def build_roadmap(missing_skills, resources=None):
    """
    missing_skills : list[str] (from gap_analysis.get_missing_skills)

    Returns: list of dicts, one per skill, in learning order:
        {skill_name, resources: [ {title, url, difficulty}, ... ]}
    """
    if resources is None:
        resources = load_resources()

    ordered_skills = _sequence_skills(missing_skills)

    roadmap = []
    for skill in ordered_skills:
        roadmap.append({
            "skill_name": skill,
            "resources": resources.get(skill, [
                {"title": f"Search: {skill} tutorial", "url": "#", "difficulty": "n/a"}
            ]),
        })
    return roadmap


# ---- Quick manual test ----
if __name__ == "__main__":
    fake_missing = ["scikit-learn", "pandas", "python", "numpy"]
    roadmap = build_roadmap(fake_missing)
    for step in roadmap:
        print(step["skill_name"], "->", [r["title"] for r in step["resources"]])
