"""
app.py
-------
Entry point. Run with:  streamlit run app.py

This file only handles: page config, DB init, session state init,
and the Home page content. All other pages live in /pages and are
auto-detected by Streamlit's multipage navigation.
"""

import streamlit as st
from modules.db_manager import init_db

st.set_page_config(
    page_title="SkillMap — Career Recommendation System",
    page_icon="🎯",
    layout="wide",
)

# Create tables on first run (safe to call every time)
init_db()

# Session state holds the currently active student across pages
if "student_id" not in st.session_state:
    st.session_state["student_id"] = None

st.title("🎯 SkillMap")
st.subheader("AI-Powered Student Skill Gap Analysis & Career Recommendation System")

st.markdown("""
Welcome! SkillMap analyzes your academic profile, skills, and interests to:

- 📊 Recommend the careers that best fit your current skill set
- 🔍 Identify exactly which skills you're missing for your dream role
- 🗺️ Generate a personalized, step-by-step learning roadmap
- ✅ Track your progress as you close each skill gap

---

### How it works
1. Fill out your profile on the **Profile Form** page (sidebar, left)
2. View your personalized **Dashboard** with career match scores
3. Follow your **Learning Roadmap** to close skill gaps
4. Check off skills as you learn them on the **Progress Tracker**
""")

if st.session_state["student_id"]:
    st.success(f"Active profile loaded — Student ID {st.session_state['student_id']}. "
               f"Head to the Dashboard from the sidebar.")
else:
    st.info("👈 Start by filling out the **Profile Form** in the sidebar.")
