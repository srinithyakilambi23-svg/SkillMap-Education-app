"""
1_Profile_Form.py
-------------------
Collects the student's profile and writes it to SQLite via
db_manager.insert_student(). On success, stores the new student_id
in st.session_state so the Dashboard/Roadmap/Progress pages know
which student to load.
"""

import streamlit as st
from modules.db_manager import init_db, insert_student
from modules.recommender import load_careers
from utils.constants import MASTER_SKILL_LIST, INTEREST_TAGS, DEPARTMENTS, YEARS

init_db()

st.title("📝 Student Profile Form")
st.caption("Fill in your details as accurately as possible — this powers every "
           "recommendation on the Dashboard.")

careers = load_careers()
career_names = [c["career_name"] for c in careers]

with st.form("profile_form", clear_on_submit=False):
    col1, col2 = st.columns(2)

    with col1:
        name = st.text_input("Full Name *")
        cgpa = st.number_input("CGPA (out of 10)", min_value=0.0, max_value=10.0,
                                step=0.01, value=7.0)
        department = st.selectbox("Department", DEPARTMENTS)
        year = st.selectbox("Year of Study", YEARS)

    with col2:
        target_career = st.selectbox("Target Career", career_names)
        interests = st.multiselect("Interests", INTEREST_TAGS)
        certifications_raw = st.text_area(
            "Certifications (one per line, optional)",
            placeholder="e.g.\nGoogle Data Analytics Certificate\nAWS Cloud Practitioner"
        )

    skills = st.multiselect(
        "Technical Skills *",
        options=MASTER_SKILL_LIST,
        help="Select every skill you currently have, even at a beginner level."
    )

    projects = st.text_area("Projects (optional)", placeholder="Briefly describe 1-3 projects you've built")

    submitted = st.form_submit_button("Save Profile & Continue →", use_container_width=True)

    if submitted:
        if not name.strip():
            st.error("Please enter your name.")
        elif not skills:
            st.error("Please select at least one skill.")
        else:
            certifications = [c.strip() for c in certifications_raw.split("\n") if c.strip()]
            student_id = insert_student(
                name=name.strip(),
                cgpa=cgpa,
                department=department,
                year=year,
                target_career=target_career,
                skills=skills,
                certifications=certifications,
                interests=interests,
                projects=projects,
            )
            st.session_state["student_id"] = student_id
            st.success(f"Profile saved! (Student ID: {student_id})")
            st.info("Now open **Dashboard** from the sidebar to see your results.")
