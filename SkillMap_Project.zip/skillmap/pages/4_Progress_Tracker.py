"""
4_Progress_Tracker.py
------------------------
Checklist UI for marking gap skills as in-progress/completed.
Writes to progress_tracker via db_manager.save_progress() and shows
a live progress gauge from charts.py.
"""

import streamlit as st
from modules.db_manager import get_student, get_progress, save_progress
from modules.recommender import load_careers, get_top_careers
from modules.gap_analysis import get_missing_skills
from modules.charts import progress_gauge

st.title("✅ Progress Tracker")

student_id = st.session_state.get("student_id")
if student_id is None:
    st.warning("No active profile. Please fill out the Profile Form first.")
    st.stop()

student = get_student(student_id)
careers = load_careers()
top_careers = get_top_careers(student["skills"], careers=careers)
best_career = next(c for c in careers if c["career_name"] == top_careers[0]["career_name"])

missing_skills = get_missing_skills(student["skills"], best_career["required_skills"])

if not missing_skills:
    st.success(f"🎉 No gaps to track for {best_career['career_name']} — you're fully matched!")
    st.stop()

st.caption(f"Tracking progress toward: **{best_career['career_name']}**")

current_progress = get_progress(student_id)
STATUS_OPTIONS = ["not_started", "in_progress", "completed"]

for skill in missing_skills:
    current_status = current_progress.get(skill, "not_started")
    new_status = st.selectbox(
        skill.title(),
        options=STATUS_OPTIONS,
        index=STATUS_OPTIONS.index(current_status),
        key=f"progress_{skill}",
    )
    if new_status != current_status:
        save_progress(student_id, skill, new_status)
        st.rerun()

completed_count = sum(1 for s in missing_skills if current_progress.get(s) == "completed")

st.divider()
st.plotly_chart(
    progress_gauge(completed_count, len(missing_skills)),
    use_container_width=True,
)
