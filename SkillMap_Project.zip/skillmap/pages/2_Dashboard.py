"""
2_Dashboard.py
----------------
Pulls the active student from session_state, runs the recommender +
gap analysis, and renders every chart from modules/charts.py.
"""

import streamlit as st
from modules.db_manager import get_student, get_all_students
from modules.recommender import load_careers, get_top_careers
from modules.gap_analysis import gap_summary
from modules.charts import radar_chart, career_match_bar_chart, gap_donut_chart

st.title("📊 Your Dashboard")

# --- Resolve which student to show ---
student_id = st.session_state.get("student_id")

all_students = get_all_students()
if not all_students:
    st.warning("No profiles found yet. Please fill out the Profile Form first.")
    st.stop()

if student_id is None:
    st.info("No active profile in this session — pick one below.")
    picked = st.selectbox("Select a student", options=all_students,
                           format_func=lambda x: f"{x[1]} (ID {x[0]})")
    student_id = picked[0]
    st.session_state["student_id"] = student_id

student = get_student(student_id)
if student is None:
    st.error("Student not found.")
    st.stop()

st.markdown(f"### Welcome, {student['name']} 👋")
col_a, col_b, col_c = st.columns(3)
col_a.metric("CGPA", student["cgpa"])
col_b.metric("Skills Logged", len(student["skills"]))
col_c.metric("Target Career", student["target_career"])

st.divider()

# --- Recommendation engine ---
careers = load_careers()
top_careers = get_top_careers(student["skills"], careers=careers)

st.subheader("🏆 Top Career Matches")
st.plotly_chart(career_match_bar_chart(top_careers), use_container_width=True)

st.divider()

# --- Detailed gap analysis for the #1 recommended career ---
best_career_name = top_careers[0]["career_name"]
best_career = next(c for c in careers if c["career_name"] == best_career_name)
summary = gap_summary(student["skills"], best_career)

st.subheader(f"🔍 Skill Gap — {best_career_name}")

chart_col1, chart_col2 = st.columns(2)
with chart_col1:
    st.plotly_chart(
        radar_chart(summary["matched_skills"], summary["missing_skills"], best_career_name),
        use_container_width=True,
    )
with chart_col2:
    st.plotly_chart(
        gap_donut_chart(summary["matched_count"], summary["missing_count"]),
        use_container_width=True,
    )

st.markdown(f"**Skills you have:** {', '.join(summary['matched_skills']) or '—'}")
st.markdown(f"**Skills to learn:** {', '.join(summary['missing_skills']) or 'None — full match!'}")

if summary["missing_skills"]:
    st.info("👉 Head to **Learning Roadmap** in the sidebar to see exactly how to close these gaps.")
