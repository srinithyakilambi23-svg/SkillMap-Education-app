"""
3_Learning_Roadmap.py
------------------------
Shows the ordered skill -> resource roadmap for the student's #1
recommended career (falls back gracefully if no student is active).
"""

import streamlit as st
from modules.db_manager import get_student
from modules.recommender import load_careers, get_top_careers
from modules.gap_analysis import get_missing_skills
from modules.roadmap_generator import build_roadmap

st.title("🗺️ Your Learning Roadmap")

student_id = st.session_state.get("student_id")
if student_id is None:
    st.warning("No active profile. Please fill out the Profile Form first.")
    st.stop()

student = get_student(student_id)
careers = load_careers()
top_careers = get_top_careers(student["skills"], careers=careers)

career_options = [c["career_name"] for c in top_careers]
chosen_career_name = st.selectbox("Build a roadmap for:", career_options)

chosen_career = next(c for c in careers if c["career_name"] == chosen_career_name)
missing_skills = get_missing_skills(student["skills"], chosen_career["required_skills"])

if not missing_skills:
    st.success(f"🎉 You already have every skill required for {chosen_career_name}!")
    st.stop()

roadmap = build_roadmap(missing_skills)

st.subheader(f"Roadmap for {chosen_career_name}")
st.caption(f"{len(roadmap)} skills to learn, in recommended order.")

for i, step in enumerate(roadmap, start=1):
    with st.expander(f"Step {i}: {step['skill_name'].title()}", expanded=(i == 1)):
        for res in step["resources"]:
            st.markdown(f"- **[{res['title']}]({res['url']})** — *{res['difficulty']}*")
