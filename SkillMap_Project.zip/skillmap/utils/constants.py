"""
Central place for every fixed list used across the app.
Keeping these in ONE file means Person 1 (UI) and Person 2 (data)
are always working off the same vocabulary -- this is what makes
the set-matching in recommender.py reliable.
"""

# Master skill list shown in the multiselect on the Profile Form.
# IMPORTANT: every skill used in data/careers.csv MUST appear here,
# spelled EXACTLY the same way (lowercase, no extra spaces).
MASTER_SKILL_LIST = [
    "python", "java", "c++", "c", "javascript", "sql", "r",
    "pandas", "numpy", "scikit-learn", "tensorflow", "pytorch",
    "matplotlib", "plotly", "power bi", "tableau", "excel",
    "statistics", "machine learning", "deep learning", "nlp",
    "computer vision", "html", "css", "react", "node.js",
    "django", "flask", "rest api", "git", "docker", "kubernetes",
    "aws", "azure", "gcp", "linux", "networking", "cybersecurity",
    "figma", "ui design", "ux research", "agile", "jira",
    "data structures", "algorithms", "dbms", "mongodb",
    "android", "ios", "flutter", "communication",
    "opencv", "cloud",
]

# Interest tags shown as a multiselect -- used only as a soft
# tie-breaker when two careers have an equal match percentage.
INTEREST_TAGS = [
    "data", "web development", "mobile apps", "artificial intelligence",
    "cloud & infrastructure", "cybersecurity", "design", "product management",
    "core software engineering", "research",
]

DEPARTMENTS = [
    "Computer Science", "Information Technology", "Electronics & Communication",
    "Mechanical", "Civil", "Electrical", "Biotechnology", "Other",
]

YEARS = [1, 2, 3, 4]

# Path constants (kept here so every module imports the same paths)
DB_PATH = "data/skillmap.db"
CAREERS_CSV = "data/careers.csv"
RESOURCES_CSV = "data/resources.csv"

# Theme colors (used by charts.py and can be reused in custom CSS)
THEME = {
    "primary": "#6C63FF",
    "secondary": "#00C9A7",
    "accent": "#FFC93C",
    "background": "#0E1117",
    "text": "#FFFFFF",
}

# How many top careers to show on the dashboard
TOP_N_CAREERS = 3
